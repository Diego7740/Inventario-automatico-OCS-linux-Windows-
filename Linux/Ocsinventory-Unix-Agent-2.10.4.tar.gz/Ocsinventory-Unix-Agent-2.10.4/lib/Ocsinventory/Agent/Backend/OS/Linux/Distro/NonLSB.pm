package Ocsinventory::Agent::Backend::OS::Linux::Distro::NonLSB;

$runMeIfTheseChecksFailed = ["Ocsinventory::Agent::Backend::OS::Linux::Distro::OSRelease"];

1;
